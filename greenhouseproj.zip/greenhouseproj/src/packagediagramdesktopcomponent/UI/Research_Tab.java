package packagediagramdesktopcomponent.UI;

import packagediagramdesktopcomponent.Business_Logic.*;

public class Research_Tab {

	/**
	 * 
	 * @param parameter
	 */
	public void getDettagliColtivazione(ColtivazioneBusiness parameter) {

	}

}