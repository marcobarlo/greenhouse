package packagediagramdesktopcomponent.UI;

public class Coltivazione_tab {

	public void validaValori() {
		// TODO - implement Coltivazione_tab.validaValori
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param temp
	 * @param irradianza
	 * @param umdita
	 */
	public void modificaParametriAmbientali(float temp, float irradianza, float umdita) {
		// TODO - implement Coltivazione_tab.modificaParametriAmbientali
		throw new UnsupportedOperationException();
	}

}