package ormsamples;

import org.orm.PersistentException;

import packagediagramdesktopcomponent.model.*;

public class provadb {
	public static void main(String[] args) throws PersistentException {
		Sezione sez[];
		SezioneCriteria sezcrit;
		sezcrit = new SezioneCriteria();
		sez = sezcrit.listSezione();
		System.out.println(sez[0].aree.size());
	}
	
	
}
