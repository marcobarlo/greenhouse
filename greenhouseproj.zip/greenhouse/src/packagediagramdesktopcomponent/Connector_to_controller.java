package packagediagramdesktopcomponent;

public class Connector_to_controller {
}