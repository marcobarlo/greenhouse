/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: 
 * License Type: Evaluation
 */
package packagediagramdesktopcomponent.model;

public interface ORMConstants extends org.orm.util.ORMBaseConstants {
	final int KEY_AREACOLTIVATA_AMBIENTE = 2086096012;
	
	final int KEY_AREACOLTIVATA_COLTIVAZIONE = -98183242;
	
	final int KEY_AREACOLTIVATA_SEZIONE = -790179290;
	
	final int KEY_COLTIVAZIONE_AREA = -1469089739;
	
	final int KEY_COLTIVAZIONE_DESCRIZIONE = 1718055079;
	
	final int KEY_COLTIVAZIONE_IMPIEGATO = 1492442133;
	
	final int KEY_DESCRIZIONECOLTIVAZIONE_COLTIVAZIONI = 278075604;
	
	final int KEY_SEZIONE_AREE = -281641237;
	
}
