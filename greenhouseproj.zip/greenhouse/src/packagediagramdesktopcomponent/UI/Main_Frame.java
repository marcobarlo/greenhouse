package packagediagramdesktopcomponent.UI;

public class Main_Frame {

	public void ricercaColtivazione() {
		// TODO - implement Main_Frame.ricercaColtivazione
		throw new UnsupportedOperationException();
	}

}