package packagediagramdesktopcomponent.UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import packagediagramdesktopcomponent.Business_Logic.*;
import javax.swing.SwingConstants;
import java.awt.Font;

public class Coltivazione_tab extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Coltivazione_tab frame = new Coltivazione_tab(new ColtivazioneBusiness());
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Coltivazione_tab(ColtivazioneBusiness colt) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setLayout(null);

		JLabel lblTipo = new JLabel("Tipo: ");
		lblTipo.setBounds(34, 62, 105, 14);
		contentPane.add(lblTipo);

		JLabel lblSezione = new JLabel("Sezione: ");
		lblSezione.setBounds(34, 109, 70, 14);
		contentPane.add(lblSezione);

		JLabel lblRiga = new JLabel("Riga: ");
		lblRiga.setBounds(34, 36, 119, 14);
		contentPane.add(lblRiga);

		JLabel lblPosizioneNellaRiga = new JLabel("Posizione: ");
		lblPosizioneNellaRiga.setBounds(34, 87, 105, 14);
		contentPane.add(lblPosizioneNellaRiga);

		JLabel lblDescrizione = new JLabel("Descrizione: ");
		lblDescrizione.setBounds(34, 134, 319, 14);
		contentPane.add(lblDescrizione);

		JLabel lblTemp = new JLabel("Temperatura: ");
		lblTemp.setBounds(272, 177, 119, 14);
		contentPane.add(lblTemp);

		JLabel lblUmidita = new JLabel("Umidit�: ");
		lblUmidita.setBounds(34, 177, 92, 14);
		contentPane.add(lblUmidita);

		JLabel lblluce = new JLabel("Irradianza: ");
		lblluce.setBounds(155, 177, 88, 14);
		contentPane.add(lblluce);
		
		JLabel dettagli = new JLabel("Dettagli Coltivazione");
		dettagli.setFont(new Font("Tahoma", Font.PLAIN, 20));
		dettagli.setHorizontalAlignment(SwingConstants.TRAILING);
		dettagli.setBounds(137, 11, 187, 25);
		contentPane.add(dettagli);

		DettagliBusiness dett= ControllerFacade.getDettagliColtivazione(colt.getID_coltivazione());
		
		lblTipo.setText("Tipo: "+colt.getTipo());
		lblSezione.setText("Sezione: "+colt.getSezione());
		lblRiga.setText("Fila: "+colt.getFila());
		lblPosizioneNellaRiga.setText("Posizione: "+colt.getPosizione());
		lblDescrizione.setText("Descrizione: "+dett.getDescrizione());
		lblTemp.setText("Temperatura: "+dett.getTemperatura_target());
		lblUmidita.setText("Umidit�: "+dett.getUmidita_target());
		lblluce.setText("Irradianza: "+dett.getIrradianza_target());

	}
} 