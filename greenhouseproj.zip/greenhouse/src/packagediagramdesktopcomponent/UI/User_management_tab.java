package packagediagramdesktopcomponent.UI;

public class User_management_tab {
}