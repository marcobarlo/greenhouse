package packagediagramdesktopcomponent.Business_Logic;

public class ControllerParametriAmbientali {

	/**
	 * 
	 * @param coltivaz
	 * @param temp
	 * @param irradianza
	 * @param umdita
	 */
	public static void modificaAmbiente(ColtivazioneBusiness coltivaz, float temp, float irradianza, float umdita) {

	}

}