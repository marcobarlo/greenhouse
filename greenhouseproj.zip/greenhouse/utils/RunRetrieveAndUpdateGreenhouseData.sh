#! /bin/sh

./RunSample.sh ormsamples.RetrieveAndUpdateGreenhouseData  $@
