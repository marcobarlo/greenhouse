#! /bin/sh

./RunSample.sh ormsamples.CreateGreenhouseData  $@
