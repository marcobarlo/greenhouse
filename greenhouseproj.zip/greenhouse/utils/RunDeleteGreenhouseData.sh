#! /bin/sh

./RunSample.sh ormsamples.DeleteGreenhouseData  $@
