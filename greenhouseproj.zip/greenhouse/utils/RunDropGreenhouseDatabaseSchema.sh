#! /bin/sh

./RunSample.sh ormsamples.DropGreenhouseDatabaseSchema  $@
