#! /bin/sh

./RunSample.sh ormsamples.ListGreenhouseData  $@
