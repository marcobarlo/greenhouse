#! /bin/sh

./RunSample.sh ormsamples.CreateGreenhouseDatabaseSchema  $@
